import 'package:flutter/material.dart';
import 'package:professeur/screens/attendance/home_attendance.dart';
import 'package:professeur/screens/notes/home_result.dart';
import 'package:professeur/screens/notes/select_module.dart';
import 'package:professeur/screens/profile/home_profile.dart';
import 'package:professeur/screens/welcome/welcome_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      //removing debug banner
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: WelcomeScreen(),
    );
  }
}


