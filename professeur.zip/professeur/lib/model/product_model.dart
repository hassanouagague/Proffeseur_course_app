import 'package:flutter/material.dart';

class Product {
  final String image, title;
  final int id;
  final Color color;
  Product({
    required this.image,
    required this.title,
    //required this.courses,
    required this.color,
    required this.id,
  });
}

List<Product> products = [
  Product(
    id: 1,
    title: "Resultats",
    image: "assets/images/Exam.png",
    color: Color(0xFF71b8ff).withOpacity(0.8),
    //courses: 16,
  ),
  Product(
    id: 2,
    title: "Profile",
    image: "assets/images/teacher2.png",
    color: Color(0xFFff6374).withOpacity(0.8),
    //courses: 22,
  ),
  Product(
    id: 3,
    title: "Présence",
    image: "assets/images/abs.png",
    color: Color(0xFFffaa5b).withOpacity(0.8),
    //courses: 15,
  ),
  Product(
    id: 4,
    title: "Course",
    image: "assets/images/programming.png",
    color: Color(0xFF9ba0fc).withOpacity(0.8),
    //courses: 18,
  ),

  Product(
    id: 5,
    title: "Calendrier",
    image: "assets/images/calendrier.png",
    color: Colors.greenAccent.withOpacity(0.8),
    //courses: 13,
  ),
];
