class User {
  final String firstName;
  final String lastName;
  final String note;
  final String cne;

  const User({
    required this.cne,
    required this.firstName,
    required this.lastName,
    required this.note,
  });

  User copy({
    String? cne,
    String? firstName,
    String? lastName,
    String? note,
  }) =>
      User(
        cne: cne ?? this.cne,
        firstName: firstName ?? this.firstName,
        lastName: lastName ?? this.lastName,
        note: note ?? this. note,
      );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is User &&
          runtimeType == other.runtimeType &&
          cne == other.cne &&
          firstName == other.firstName &&
          lastName == other.lastName &&
          note == other.note;

  @override
  int get hashCode =>  cne.hashCode ^ firstName.hashCode ^ lastName.hashCode ^ note.hashCode;
}
