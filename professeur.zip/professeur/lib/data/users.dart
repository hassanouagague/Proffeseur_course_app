
import 'package:professeur/model/user.dart';

final allUsers = <User>[
  User(cne:'B1300863' ,firstName: 'Nadia', lastName: 'Kentaoui', note: '16.0'),
  User(cne:'D1520830' ,firstName: 'Anass', lastName: 'Nehhassi', note: '17.5'),
  User(cne:'D1504566' ,firstName: 'Soufiane', lastName: 'Alawad', note: '12.4'),
  User(cne:'D1301130' ,firstName: 'Anas', lastName: 'Jabli', note: '16.0'),
  User(cne:'B1409871' ,firstName: 'Soukaina', lastName: 'Jomani', note: '15'),
  User(cne:'J3200983' ,firstName: 'Aicha', lastName: 'Kebdani', note: '12.0'),
  User(cne:'D1305437' ,firstName: 'Mohamed', lastName: 'Sidik', note: '08.5'),
  User(cne:'D3156001' ,firstName: 'Fatima', lastName: 'Bouzid', note: '14.7'),
  User(cne:'C1900632' ,firstName: 'Abderahman', lastName: 'Fathi', note: '14'),
  User(cne:'D1430821' ,firstName: 'Salma', lastName: 'Nabily', note: '19.5'),
  User(cne:'D1863003' ,firstName: 'hajar', lastName: 'Kouroub', note: '9.0'),
  User(cne:'D1500866' ,firstName: 'Meriam', lastName: 'Kouroub', note: '9.5'),
  User(cne:'C1350052' ,firstName: 'Mehdi', lastName: 'Nadi', note: '13.5'),
  User(cne:'J1611943' ,firstName: 'Mohamed', lastName: 'Adnane', note: '15.7'),
  User(cne:'B2200611' ,firstName: 'Muhsin', lastName: 'Farah', note: '15.6'),
  User(cne:'C2300842' ,firstName: 'Hussam', lastName: 'Nadi', note: '7.0'),
  User(cne:'D1557009' ,firstName: 'Hasna', lastName: 'Dawdi', note: '15.4'),

];
