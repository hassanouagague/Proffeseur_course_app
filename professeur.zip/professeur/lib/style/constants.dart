import 'package:flutter/material.dart';
import 'dart:ui';

const kpink = Color(0xFFff6374);
const kgreen = Color(0x76ff7a);
const kblue = Color(0xFF71b8ff);
const kpurple = Color(0xFF9ba0fc);
const korange = Color(0xFFffaa5b);



mixin AppColor {
  static Color primary = Color(0xFF2855AE);
  static Color primaryLight = Color(0xFF7292CF);
  static Color darkText = Color(0xFF777777);
  static Color primarytest = Color(0x4B0082);
}
