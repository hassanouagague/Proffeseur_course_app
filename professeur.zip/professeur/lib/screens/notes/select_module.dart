import 'package:flutter/material.dart';
import 'package:professeur/screens/notes/editable_page.dart';

class Selected extends StatefulWidget {
  const Selected({Key? key}) : super(key: key);

  @override
  State<Selected> createState() => _SelectedState();
}

class _SelectedState extends State<Selected> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Selected Module'),),
      body:  Center(
        child: DropdownExample(),
      ),
    );
  }
}
class DropdownExample extends StatefulWidget {
  @override
  _DropdownExampleState createState() {
    return _DropdownExampleState();
  }
}

class _DropdownExampleState extends State<DropdownExample> {
  String? _value;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Center(
          child: DropdownButton<String>(
            items: [
              DropdownMenuItem<String>(
                child: Text('The Basic of Computer Scienc'),
                value: 'one',
              ),
              DropdownMenuItem<String>(
                child: Text('Network'),
                value: 'two',
              ),
              DropdownMenuItem<String>(
                child: Text('Artificial Intelligence'),
                value: 'three',
              ),
            ],
            onChanged: (String? value) {
              setState(() {
                _value = value;
              });
            },
            hint: Text('Select Module'),
            value: _value,
          ),

        ),
        SizedBox(height: 16.0,),
        Container(
          //margin: EdgeInsets.all(16),
          child: FlatButton(
            child: Text(
              'Sent',
              style: TextStyle(fontSize: 18.0),
            ),
            color: Colors.cyan,
            textColor: Colors.white70,
            onPressed: () {
              _navigateToSecondScreen(context);
            },
          ),
        ),
      ],
    );
  }
  void _navigateToSecondScreen(BuildContext context) {
    Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => EditablePage(),
        ));
  }
}
