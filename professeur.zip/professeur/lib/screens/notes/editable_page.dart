
import 'package:flutter/material.dart';
import 'package:professeur/data/users.dart';
import 'package:professeur/model/user.dart';
import 'package:professeur/screens/components/scrollable_widget.dart';
import 'package:professeur/screens/components/tabbar_widget.dart';
import 'package:professeur/screens/components/text_dialog_widget.dart';
import 'package:professeur/screens/notes/utils.dart';
import 'package:professeur/style/constants.dart';
import 'package:professeur/style/text_style.dart';

class EditablePage extends StatefulWidget {
  @override
  _EditablePageState createState() => _EditablePageState();
}

class _EditablePageState extends State<EditablePage> {
  late List<User> users;

  @override
  void initState() {
    super.initState();

    this.users = List.of(allUsers);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(
        "Students results",
        style: TextStyle(
          fontSize: 25,
          fontWeight: FontWeight.w500,
          color: Colors.white,
        ),
      ),

    ),
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Colors.white70, Colors.white]),
          ),
          child: Column(
            children: [
              Stack(
                alignment: Alignment.bottomLeft,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        SizedBox(height: 50),
                        Text(
                          "Module:",
                          style: AppTextStyle.style(
                              color: Colors.black54,

                              fontSize: 34, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          "The Basic of Computer Science",
                          style: AppTextStyle.style(
                              fontSize: 20,
                              color: Colors.blue.withOpacity(0.8),
                              fontWeight: FontWeight.w300),
                        ),
                      ],
                    ),
                  )
                ],
              ),
              Expanded(
                  child: ScrollableWidget(child: buildDataTable())
              ),
              Container(
                margin: EdgeInsets.all(16),
                child: FlatButton(
                  child: Text(
                    'sent',
                    style: TextStyle(fontSize: 18.0),
                  ),
                  color: Colors.cyan,
                  textColor: Colors.white70,
                  onPressed: () {},
                ),
              ),
            ],
          ),
        ),
      );

  Widget buildDataTable() {
    final columns = ['Cne','First Name', 'Last Name', 'Note'];

    return DataTable(
      columns: getColumns(columns),
      rows: getRows(users),
    );
  }

  List<DataColumn> getColumns(List<String> columns) {
    return columns.map((String column) {
      final isNote = column == columns[3];

      return DataColumn(
        label: Text(column),
        numeric: isNote,
      );
    }).toList();
  }

  List<DataRow> getRows(List<User> users) => users.map((User user) {
        final cells = [user.cne, user.firstName, user.lastName, user.note];

        return DataRow(
          cells: Utils.modelBuilder(cells, (index, cell) {
            final showEditIcon = index == 3 ;

            return DataCell(
              Text('$cell'),
              showEditIcon: showEditIcon,
              onTap: () {
                switch (index) {
                  case 3:
                    editNote(user);
                    break;

                }
              },
            );
          }),
        );
      }).toList();

  Future editNote(User editUser) async {
    final note = await showTextDialog(
      context,
      title: 'Change Note',
      value: editUser.note,
    );

    setState(() => users = users.map((user) {
          final isEditedUser = user == editUser;

          return isEditedUser ? user.copy(note: note) : user;
        }).toList());
  }
}


class DropdownExample extends StatefulWidget {
  @override
  _DropdownExampleState createState() {
    return _DropdownExampleState();
  }
}

class _DropdownExampleState extends State<DropdownExample> {
  String? _value;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: DropdownButton<String>(
        items: [
          DropdownMenuItem<String>(
            child: Text('Item 1'),
            value: 'one',
          ),
          DropdownMenuItem<String>(
            child: Text('Item 2'),
            value: 'two',
          ),
          DropdownMenuItem<String>(
            child: Text('Item 3'),
            value: 'three',
          ),
        ],
        onChanged: (String? value) {
          setState(() {
            _value = value;
          });
        },
        hint: Text('Select Item'),
        value: _value,
      ),
    );
  }
}
