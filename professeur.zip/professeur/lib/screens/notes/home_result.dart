
import 'package:flutter/material.dart';
import 'package:professeur/screens/home/home_screen.dart';
import 'package:professeur/screens/notes/editable_page.dart';
import 'package:professeur/screens/notes/select_module.dart';
import 'package:professeur/screens/notes/sortable_page.dart';
import 'package:professeur/screens/profile/ProfilePage.dart';

class HomeResult extends StatefulWidget {
  const HomeResult({Key? key}) : super(key: key);

  @override
  State<HomeResult> createState() => _HomeResultState();
}

class _HomeResultState extends State<HomeResult> {
  double screenHeight=0;
  double screenWidth=0;

  Color primary = const Color(0xffeef444c);

  //int currentIndex =0;
  int _selectedItemIndex = 1;
  final List pages = [
    HomeScreen(),
    Selected(),
    null,
    null,
    ProfilePage(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: BottomNavigationBar(
          elevation: 0,
          backgroundColor: Color(0xFFF0F0F0),
          unselectedItemColor: Colors.grey,
          selectedItemColor: Colors.black,
          selectedIconTheme: IconThemeData(color: Colors.blueGrey[600]),
          currentIndex: _selectedItemIndex,
          type: BottomNavigationBarType.fixed,
          onTap: (int index) {
            setState(() {
              _selectedItemIndex = index;
            });
          },
          items: [
            BottomNavigationBarItem(
              label: '',
              icon: Icon(Icons.home),
            ),
            BottomNavigationBarItem(
              label: '',
              icon: Icon(Icons.task),
            ),
            BottomNavigationBarItem(
              label: '',
              icon: Icon(Icons.check),
            ),
            BottomNavigationBarItem(

              label: '',
              icon: Icon(Icons.calendar_today),
            ),
            BottomNavigationBarItem(
              label: '',
              icon: Icon(Icons.chat_bubble),
            ),
          ],
        ),
        body: pages[_selectedItemIndex]

    );
  }
}
